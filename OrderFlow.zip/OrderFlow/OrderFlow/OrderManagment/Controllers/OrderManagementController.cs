﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace OrderManagment.Controllers
{
    [Route("api/order")]
    [ApiController]
    public class OrderManagementController : ControllerBase
    {
        [HttpPost]
        [Route("postOrder")]
        public int UpdateStockInfo(string orderXML)
        {
            return 1;
        }
    }
}
