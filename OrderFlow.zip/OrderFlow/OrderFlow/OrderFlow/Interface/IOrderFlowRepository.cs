﻿using OrderFlow.Model;

namespace OrderFlow.Interface
{
    public interface IOrderProcessingService
    {
        Task<OrderProcessResponse> ProcessOrderAsync(string[] OrderLines);
        Task<int> UpdateStock(Stock stock);
    }
}
