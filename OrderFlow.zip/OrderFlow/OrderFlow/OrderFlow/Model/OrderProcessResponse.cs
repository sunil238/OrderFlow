﻿namespace OrderFlow.Model
{
    public class OrderProcessResponse
    {
        public bool? OrderDelivery { get; set; }
        public bool? IsError { get; set; }
        public List<string> ErrorLines { get; set; }
    }
}
