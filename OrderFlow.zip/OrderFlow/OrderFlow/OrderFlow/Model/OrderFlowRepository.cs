﻿namespace OrderFlow.Model

{
    public class OrderFlowRepository
    {
        private ApplicationDBContext context;
        public ApplicationDBContext Context { get { return context; } }
        public OrderFlowRepository(ApplicationDBContext _context)
        {
            context = _context;
        }
        public OrderFlowRepository()
        {
            context = new ApplicationDBContext();
        }
        #region Library for Repository Services

        #region-To get all PriceList details by EAN Code
        public List<PriceList> GetAllPriceListbyEAN(string EANCode)
        {
            List<PriceList> lstPricelIst = null;
            try
            {
                lstPricelIst = (from p in context.PriceLists
                                where p.EANCode.Equals(EANCode)
                                select p).ToList();
            }
            catch (Exception)
            {
                lstPricelIst = null;
            }
            return lstPricelIst;
        }
        #endregion
        #region-To get Setting by Name
        public string GetSettingByName(string name)
        {
            Settings settingValue = new Settings();
            try
            {
                settingValue = (from p in context.Settings
                                where p.Name.Equals(name)
                                select p).FirstOrDefault();
            }
            catch (Exception)
            {
                settingValue = null;
            }
            return settingValue.Value.ToString();
        }
        #endregion
        #endregion
    }
}
