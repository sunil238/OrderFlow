﻿namespace OrderFlow.Model
{
    public class Order
    {
        public string? OrderId { get; set; }
        public string? OrderNumber { get; set; }
        public String OrderDate { get; set; }
        public string? EANBuyerCode { get; set; }
        public string? EANSupplierCode { get; set; }
        public string? Comment { get; set; }
        public List<OrderLines>? orderLines { get; set; }
    }
    public class OrderLines
    {
        public string? EANCode { get; set; }
        public string? ArticleDescription { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
