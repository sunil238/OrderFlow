﻿using System.ComponentModel.DataAnnotations;

namespace OrderFlow.Model
{
    public class Settings
    {
        [Key]
        public string? Name { get; set; }
        [Required]
        public string? Value { get; set; }
    }
}
