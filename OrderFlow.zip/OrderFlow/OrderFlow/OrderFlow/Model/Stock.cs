﻿namespace OrderFlow.Model
{
    public class Stock
    {
        public string? EANCode { get; set; }
        public int StockQuantity { get; set; }
    }
}
