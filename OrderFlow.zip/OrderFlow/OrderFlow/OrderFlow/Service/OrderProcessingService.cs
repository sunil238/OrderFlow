﻿using Microsoft.Rest;
using Microsoft.Rest.Serialization;
using Newtonsoft.Json;
using OrderFlow.Interface;
using OrderFlow.Model;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Xml.Serialization;

namespace OrderFlow.Service
{
    public class OrderProcessingService : IOrderProcessingService
    {
        OrderFlowRepository _repository;
        JsonSerializerSettings DeserializerSettings = new JsonSerializerSettings
        {
            DateFormatHandling = DateFormatHandling.IsoDateFormat,
            DateTimeZoneHandling = DateTimeZoneHandling.Utc,
            NullValueHandling = NullValueHandling.Ignore,
            ReferenceLoopHandling = ReferenceLoopHandling.Serialize,
            ContractResolver = new ReadOnlyJsonContractResolver(),
            Converters = new List<JsonConverter>
                { new Iso8601TimeSpanConverter()}
        };
        string endPoint = string.Empty;
        string URL = string.Empty;
        string BaseURL = string.Empty;
        HttpRequestMessage _httpRequest = new HttpRequestMessage();
        HttpClient httpClient = new HttpClient();
        HttpResponseMessage? _httpResponse = null;
        string? _responseContent = null;
        HttpOperationResponse<object> _result = new HttpOperationResponse<object>();
        public OrderProcessingService()
        {
            _repository = new OrderFlowRepository();
        }
        /// <summary>
        /// Service used to validate incoming order details in flat file and sending it to order management system
        /// </summary>
        /// <param name="OrderLines"></param>
        /// <returns></returns>
        public async Task<OrderProcessResponse> ProcessOrderAsync(string[] OrderLines)
        {
            int lineNumber = 0;
            OrderProcessResponse orderProcess = new OrderProcessResponse
            {
                OrderDelivery = false,
                IsError = false,
                ErrorLines = new List<string>()
            };
            Order order = new Order();
            order.orderLines = new List<OrderLines>();
            foreach (var OrderLine in OrderLines)
            {
                if (lineNumber == 0)
                {
                    if (OrderLine.Length < 49)
                    {
                        orderProcess.IsError = true;
                        orderProcess.ErrorLines.Add("Header does not have sufficient information");
                        return orderProcess;
                    }
                    order.OrderId = Guid.NewGuid().ToString();
                    if (OrderLine.Substring(0, 3) != "ORD")
                    {
                        orderProcess.IsError = true;
                        orderProcess.ErrorLines.Add("File Type is wrong");
                        return orderProcess;
                    }
                    order.OrderNumber = OrderLine.Substring(0, 3) + OrderLine.Substring(3, 20).Trim();
                    order.OrderDate = OrderLine.Substring(23, 13).Trim();
                    order.EANBuyerCode = OrderLine.Substring(36, 13).Trim();
                    order.EANSupplierCode = OrderLine.Substring(49, 13).Trim();
                    order.Comment = OrderLine.Substring(62);
                }
                else
                {
                    OrderLines orderLine = new OrderLines();
                    if (OrderLine.Length < 88)
                    {
                        orderProcess.IsError = true;
                        orderProcess.ErrorLines.Add("Order Line with line number " + lineNumber + " does not have sufficient information");
                        return orderProcess;
                    }
                    orderLine.EANCode = OrderLine.Substring(0, 13).Trim();
                    orderLine.ArticleDescription = OrderLine.Substring(13, 65).Trim();
                    orderLine.Quantity = Convert.ToInt32(OrderLine.Substring(78, 10).Trim());
                    orderLine.Price = Convert.ToDecimal(OrderLine.Substring(88));
                    var priceLists = _repository.GetAllPriceListbyEAN(OrderLine.Substring(0, 13).Trim());
                    var refinedPLWithBuyer = priceLists?.Where(x => x.EANBuyerCode == order.EANBuyerCode).ToList();
                    if (refinedPLWithBuyer != null)
                    {
                        orderLine.Price = refinedPLWithBuyer.FirstOrDefault().Price;
                        orderProcess.ErrorLines.Add("Price updated for EAMCode " + orderLine.EANCode);
                    }
                    else if (priceLists != null)
                    {
                        orderLine.Price = priceLists.FirstOrDefault().Price;
                        orderProcess.ErrorLines.Add("Price updated for EAMCode " + orderLine.EANCode);
                    }
                    else
                    {
                        orderProcess.IsError = true;
                        orderProcess.ErrorLines.Add("Price unavailable for EAMCode " + orderLine.EANCode);
                        return orderProcess;
                    }
                    var stockQty =await GetStockValue(OrderLine.Substring(0, 13).Trim());
                    if (Convert.ToInt32(OrderLine.Substring(78, 10).Trim()) > stockQty)
                    {
                        orderProcess.IsError = true;
                        orderProcess.ErrorLines.Add("Ordered Stock unavailable for EAMCode " + orderLine.EANCode);
                        return orderProcess;
                    }
                    order.orderLines.Add(orderLine);
                }
                lineNumber = +1;
            }
            var stringwriter = new System.IO.StringWriter();
            XmlSerializer inst = new XmlSerializer(typeof(Order));
            inst.Serialize(stringwriter, order);
            var orderXML = stringwriter.ToString();
            var orderDelivery = await SendOrder(orderXML);
            orderProcess.OrderDelivery = orderDelivery == 1 ? true : false;
            if(orderProcess.ErrorLines.Count() > 0)
            {
                NotifyAccountManager(orderProcess);
            }
            return orderProcess;
        }
        /// <summary>
        /// Method used to send notificaiton to account manager
        /// </summary>
        /// <param name="orderProcess"></param>
        public void NotifyAccountManager(OrderProcessResponse orderProcess)
        {
            var stringwriter = new System.IO.StringWriter();
            XmlSerializer inst = new XmlSerializer(typeof(OrderProcessResponse));
            inst.Serialize(stringwriter, orderProcess);
            var orderProcessXML = stringwriter.ToString();
            var from = "testFrom@gmail.com";
            var to = "testTo@gmail.com";//Can be fetched from Settings
            var body = orderProcessXML;
            var subject = "Error/Warning During Order Process";

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("testUser", "testPass"),
                EnableSsl = true,
            };

            smtpClient.Send(from, to, subject, body);
        }
            /// <summary>
            /// Service used to push stock information into ERP inventory
            /// </summary>
            /// <param name="stock"></param>
            /// <returns></returns>
            public async Task<int> UpdateStock(Stock stock)
        {
            _httpRequest = new HttpRequestMessage();
            BaseURL = _repository.GetSettingByName("ErpURL");
            endPoint = "api/Stock/GetStockInfo";
            URL = BaseURL + endPoint + "?EAMCode=" + stock.EANCode + "&Quantity=" + stock.StockQuantity;
            _httpRequest.Method = new HttpMethod("POST");
            _httpRequest.RequestUri = new System.Uri(URL);
            _result.Request = _httpRequest;
            _result.Response = _httpResponse;
            _httpResponse = await httpClient.SendAsync(_httpRequest);
            if (Convert.ToInt32(_httpResponse.StatusCode) == 200)
            {
                _responseContent = await _httpResponse.Content.ReadAsStringAsync();
                _result.Body = JsonConvert.DeserializeObject<int>(_responseContent, DeserializerSettings);
            }
            var updateValue = 1;// Convert.ToInt32(_result.Body as string); In real time this will be replaced
            return updateValue;
        }
        /// <summary>
        /// Method to get Stock information from ERP
        /// </summary>
        /// <param name="EAMCode"></param>
        /// <returns></returns>
        public async Task<int> GetStockValue(string EAMCode)
        {
            _httpRequest = new HttpRequestMessage();
            BaseURL = _repository.GetSettingByName("ErpURL");
            endPoint = "api/Stock/GetStockInfo";
            URL = BaseURL + endPoint + "?EAMCode=" + EAMCode;
            _httpRequest.Method = new HttpMethod("GET");
            _httpRequest.RequestUri = new System.Uri(URL);
            _result.Request = _httpRequest;
            _result.Response = _httpResponse;
            _httpResponse = await httpClient.SendAsync(_httpRequest);
            if (Convert.ToInt32(_httpResponse.StatusCode) == 200)
            {
                _responseContent = await _httpResponse.Content.ReadAsStringAsync();
                _result.Body = JsonConvert.DeserializeObject<int>(_responseContent, DeserializerSettings);
            }
            var stockQty = 500;// Convert.ToInt32(_result.Body as string); In real time this will be replaced
            return stockQty;
        }
        /// <summary>
        /// Method used to Send Order to Order Management System
        /// </summary>
        /// <param name="orderXML"></param>
        /// <returns></returns>
        public async Task<int> SendOrder(string orderXML)
        {
            _httpRequest = new HttpRequestMessage();
            BaseURL = _repository.GetSettingByName("OrderManagment");
            endPoint = "api/order/postOrder";
            URL = BaseURL + endPoint;
            _httpRequest.Content = new StringContent(orderXML,Encoding.UTF8,"text/xml");
            _httpRequest.Method = new HttpMethod("POST");
            _httpRequest.RequestUri = new System.Uri(URL);
            _result.Request = _httpRequest;
            _result.Response = _httpResponse;
            _httpResponse = await httpClient.SendAsync(_httpRequest);
            if (Convert.ToInt32(_httpResponse.StatusCode) == 200)
            {
                _responseContent = await _httpResponse.Content.ReadAsStringAsync();
                _result.Body = JsonConvert.DeserializeObject<int>(_responseContent, DeserializerSettings);
            }
            var orderdelivery = 1;// Convert.ToInt32(_result.Body as string); In real time this will be replaced
            return orderdelivery;
        }
    }
}
