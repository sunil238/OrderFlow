﻿using Microsoft.EntityFrameworkCore;
using OrderFlow.Model;

namespace OrderFlow
{
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext()
        {

        }
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PriceList>().HasData(
                new PriceList
                {
                    PriceListId = Guid.NewGuid().ToString(),
                    EANCode = "8712345678906",
                    EANBuyerCode = "8712345678937",
                    Price = 123.35m
                },
                new PriceList
                {
                    PriceListId = Guid.NewGuid().ToString(),
                    EANCode = "8712345678913",
                    EANBuyerCode = "8712345678937",
                    Price = 56.00m
                },
                new PriceList
                {
                    PriceListId = Guid.NewGuid().ToString(),
                    EANCode = "8712345678920",
                    EANBuyerCode = "8712345678937",
                    Price = 12.90m
                });
         }
        public DbSet<PriceList> PriceLists { get; set; }
        public DbSet<Settings> Settings { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var builder = new ConfigurationBuilder()
                       .SetBasePath(Directory.GetCurrentDirectory())
                       .AddJsonFile("appsettings.json");
            var config = builder.Build();
            var connectionString = config.GetConnectionString("DefaultConnString");
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(connectionString);
            }
        }
    }
}
