﻿using Microsoft.AspNetCore.Mvc;
using OrderFlow.Interface;
using OrderFlow.Model;

namespace OrderFlow.Controllers
{
    [Route("api/Order")]
    [ApiController]
    public class OrderProcessingController : ControllerBase
    {
        private readonly IOrderProcessingService _orderProcessingService;
        public OrderProcessingController(IOrderProcessingService orderProcessingService)
        {
            _orderProcessingService = orderProcessingService;
        }
        [HttpPost]
        [Route("Process")]
        public async Task<OrderProcessResponse> ProcessOrders(string FileLocation)
        {
            OrderProcessResponse orderProcess = new OrderProcessResponse
            {
                IsError = false
            };
            string[] OrderLines = System.IO.File.ReadAllLines(FileLocation);
            if (OrderLines.Count() <= 0)
            {
                orderProcess.ErrorLines.Add("Empty file entered as input");
            }
            else
            {
                orderProcess = await _orderProcessingService.ProcessOrderAsync(OrderLines);
            }
            return orderProcess;
        }
        [HttpPost]
        [Route("UpdateStock")]
        public async Task<bool> UpdateStock(Stock stock)
        {
            var stockUpdate = await _orderProcessingService.UpdateStock(stock);
            return stockUpdate == 1 ? true : false;
        }
    }
}
