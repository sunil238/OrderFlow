﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace OrderFlow.Migrations
{
    /// <inheritdoc />
    public partial class V1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PriceLists",
                columns: table => new
                {
                    PriceListId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EANCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EANBuyerCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(8,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PriceLists", x => x.PriceListId);
                });

            migrationBuilder.InsertData(
                table: "PriceLists",
                columns: new[] { "PriceListId", "EANBuyerCode", "EANCode", "Price" },
                values: new object[,]
                {
                    { "c78dbd48-7667-48b5-9490-f39a942ccda8", "Outlet123", "Heinken123", 20.00m },
                    { "c78dbd48-7667-48b5-9490-f39a942ccda9", "Outlet456", "Tiger123", 30.00m }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PriceLists");
        }
    }
}
