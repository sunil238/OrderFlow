﻿using System.ComponentModel.DataAnnotations;

namespace Stock.Model
{
    public class Stock
    {
        [Required]
        public string? EANCode { get; set; }
        [Required]
        public int StockQuantity { get; set; }
    }
}
