﻿using Microsoft.AspNetCore.Mvc;

namespace Stock.Controllers
{
    [Route("api/Stock")]
    [ApiController]
    public class StockController : ControllerBase
    {
        [HttpGet]
        [Route("GetStockInfo/{EAMCode}")]
        public int GetStockInfo()
        {
            return 50;
        }
        [HttpPost]
        [Route("UpdateStockInfo/{EAMCode}/{Quantity}")]
        public int UpdateStockInfo()
        {
            return 1;
        }
    }
}
